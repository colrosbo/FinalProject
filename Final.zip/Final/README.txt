This application was created so that a an ASP.NET Core application can interact with
a database. The application will be created using the MVC pattern. It also interacts 
with an API to send the data to the application so that the user can see the results 
from what they input.