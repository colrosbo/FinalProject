using System.Collections.Generic;

namespace NorthwindMvc.Models
{
    public class Weather
    {
        public string Date {get; set;}
        public string TemperatureC {get; set;}
        public string TemperatureF {get; set;}
        public string Summary {get; set;}
    }
}